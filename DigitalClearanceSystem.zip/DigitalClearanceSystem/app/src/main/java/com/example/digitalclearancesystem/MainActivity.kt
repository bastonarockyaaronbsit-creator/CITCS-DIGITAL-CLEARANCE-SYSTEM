
package com.example.digitalclearancesystem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*

enum class AppScreen {
    LOGIN,
    REGISTER,
    RECOVER,
    DASHBOARD,
    CLEARANCE,
    REQUIREMENTS
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {

                var screen by remember {
                    mutableStateOf(AppScreen.LOGIN)
                }

                var studentName by remember {
                    mutableStateOf("")
                }

                when (screen) {

                    // LOGIN
                    AppScreen.LOGIN -> {
                        LoginScreen(
                            onLoginSuccess = { name ->
                                studentName = name
                                screen = AppScreen.DASHBOARD
                            },
                            onRegister = {
                                screen = AppScreen.REGISTER
                            },
                            onRecover = {
                                screen = AppScreen.RECOVER
                            }
                        )
                    }

                    // REGISTER
                    AppScreen.REGISTER -> {
                        RegisterScreen(
                            onBack = {
                                screen = AppScreen.LOGIN
                            }
                        )
                    }

                    // RECOVER PASSWORD
                    AppScreen.RECOVER -> {
                        RecoverScreen(
                            onBack = {
                                screen = AppScreen.LOGIN
                            }
                        )
                    }

                    // DASHBOARD
                    AppScreen.DASHBOARD -> {
                        DashboardScreen(
                            studentName = studentName,

                            onClearance = {
                                screen = AppScreen.CLEARANCE
                            },

                            onRequirements = {
                                screen = AppScreen.REQUIREMENTS
                            },

                            onLogout = {
                                studentName = ""
                                screen = AppScreen.LOGIN
                            }
                        )
                    }

                    // CLEARANCE
                    AppScreen.CLEARANCE -> {
                        ClearanceScreen(
                            onBack = {
                                screen = AppScreen.DASHBOARD
                            },
                            onHome = {
                                screen = AppScreen.DASHBOARD
                            }
                        )
                    }

                    // REQUIREMENTS
                    AppScreen.REQUIREMENTS -> {
                        RequirementsScreen(
                            onHome = {
                                screen = AppScreen.DASHBOARD
                            },

                            onClearance = {
                                screen = AppScreen.CLEARANCE
                            },

                            onRequirements = {
                                screen = AppScreen.REQUIREMENTS
                            },

                            onNotifications = {
                                // Notifications page will be added later.
                            },

                            onProfile = {
                                // Profile page will be added later.
                            },

                            onSubmitRequirement = {
                                // Submit requirement page will be added later.
                            },

                            onRequirementClick = { requirementId ->
                                // Requirement details page will be added later.
                            }
                        )
                    }
                }
            }
        }
    }
}
