
package com.example.digitalclearancesystem

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Brand = Color(0xFF80152F)
private val DeepBrand = Color(0xFF4B0B1D)
private val Page = Color(0xFFF5F6FA)
private val Ink = Color(0xFF202536)
private val Muted = Color(0xFF626C7D)
private val Border = Color(0xFFE2E5EC)
private val SoftMaroon = Color(0xFFF8E9EE)
private val Green = Color(0xFF19734B)
private val SoftGreen = Color(0xFFE8F5ED)
private val Orange = Color(0xFFA86500)
private val SoftOrange = Color(0xFFFFF2D9)
private val Red = Color(0xFFB52D43)
private val SoftRed = Color(0xFFFCEBED)
private val Blue = Color(0xFF326CC0)
private val SoftBlue = Color(0xFFEAF1FF)
private val Purple = Color(0xFF8050B5)
private val SoftPurple = Color(0xFFF2EAFE)
private val Slate = Color(0xFF596273)
private val SoftSlate = Color(0xFFEEF0F4)

private data class ActionItem(
    val title: String,
    val icon: ImageVector,
    val tint: Color,
    val background: Color
)

@Composable
fun DashboardScreen(
    studentName: String,
    onClearance: () -> Unit,
    onRequirements: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    val actions = listOf(
        ActionItem("My Clearance", Icons.Default.Description, Brand, SoftMaroon),
        ActionItem("Submit", Icons.Default.CloudUpload, Blue, SoftBlue),
        ActionItem("Notifications", Icons.Default.Notifications, Orange, SoftOrange),
        ActionItem("Help Center", Icons.Default.SupportAgent, Green, SoftGreen),
        ActionItem("Academic Records", Icons.Default.MenuBook, Blue, SoftBlue),
        ActionItem("Schedule", Icons.Default.CalendarMonth, Purple, SoftPurple),
        ActionItem("Settings", Icons.Default.Settings, Slate, SoftSlate),
        ActionItem("Logout", Icons.Default.Logout, Red, SoftRed)
    )

    Scaffold(
        containerColor = Page,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepBrand)
                    .navigationBarsPadding()
                    .height(60.dp)
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val navItems = listOf(
                    Triple("Home", Icons.Default.Home, 0),
                    Triple("Clearance", Icons.Default.Description, 1),
                    Triple("Requirements", Icons.Default.Folder, 2),
                    Triple("Notifications", Icons.Default.Notifications, 3),
                    Triple("Profile", Icons.Default.Person, 4)
                )

                navItems.forEach { item ->
                    val selected = selectedTab == item.third

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) Color.White.copy(alpha = 0.15f)
                                else Color.Transparent
                            )
                            .clickable {
                                selectedTab = item.third

                                when (item.third) {
                                    0 -> {
                                        // Already on Dashboard
                                    }

                                    1 -> onClearance()

                                    2 -> onRequirements()

                                    else -> {
                                        Toast.makeText(
                                            context,
                                            "${item.first} page is coming soon.",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = item.second,
                            contentDescription = item.first,
                            tint = if (selected) Color.White
                            else Color(0xFFE8D8DE),
                            modifier = Modifier.size(24.dp)
                        )

                        Spacer(Modifier.height(2.dp))

                        Text(
                            text = item.first,
                            color = if (selected) Color.White
                            else Color(0xFFE8D8DE),
                            fontSize = 9.sp,
                            fontWeight = if (selected) FontWeight.Bold
                            else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }
    ) { padding ->

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = padding.calculateStartPadding(
                        androidx.compose.ui.unit.LayoutDirection.Ltr
                    ),
                    end = padding.calculateEndPadding(
                        androidx.compose.ui.unit.LayoutDirection.Ltr
                    ),
                    bottom = padding.calculateBottomPadding()
                )
        ) {
            val compact = maxHeight < 760.dp
            val tiny = maxHeight < 680.dp
            val side = if (compact) 12.dp else 16.dp
            val gap = if (tiny) 6.dp else 9.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Page),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {

                // HEADER
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .background(
                            Brush.horizontalGradient(
                                listOf(DeepBrand, Brand, Color(0xFF962344))
                            )
                        )
                        .padding(
                            horizontal = side,
                            vertical = if (tiny) 8.dp else 11.dp
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.citcs_logo),
                        contentDescription = "CITCS Logo",
                        modifier = Modifier.size(if (tiny) 43.dp else 49.dp)
                    )

                    Spacer(Modifier.width(10.dp))

                    Column(Modifier.weight(1f)) {
                        Text(
                            "CITCS",
                            color = Color.White,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold,
                            lineHeight = 23.sp
                        )

                        Text(
                            "COLLEGE OF INFORMATION TECHNOLOGY",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            "AND COMPUTER STUDIES",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 11.sp
                        )

                        Text(
                            "Digital Clearance System",
                            color = Color(0xFFFFE0E8),
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                    }

                    IconButton(
                        onClick = onLogout,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                    ) {
                        Icon(
                            Icons.Default.Logout,
                            contentDescription = "Log out",
                            tint = Color.White,
                            modifier = Modifier.size(23.dp)
                        )
                    }
                }

                // STUDENT WELCOME
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(DeepBrand, Brand, Color(0xFF922341))
                            )
                        )
                        .padding(
                            horizontal = side,
                            vertical = if (tiny) 10.dp else 14.dp
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (tiny) 48.dp else 56.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = "Student profile",
                            tint = Brand,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    Column(Modifier.weight(1f)) {
                        Text(
                            "Hello, Student!",
                            fontSize = 14.sp,
                            color = Color.White
                        )

                        Text(
                            text = studentName.ifBlank { "Student" },
                            fontSize = if (tiny) 17.sp else 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Icon(
                        Icons.Default.School,
                        contentDescription = "School",
                        tint = Color.White.copy(alpha = 0.95f),
                        modifier = Modifier.size(34.dp)
                    )
                }

                // MAIN CONTENT
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(
                            start = side,
                            end = side,
                            top = gap,
                            bottom = gap
                        ),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {

                    // CLEARANCE PROGRESS
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            Border
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(
                                horizontal = 13.dp,
                                vertical = if (tiny) 8.dp else 11.dp
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconTile(
                                    Icons.Default.Assignment,
                                    Brand,
                                    SoftMaroon,
                                    40.dp
                                )

                                Spacer(Modifier.width(10.dp))

                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "Clearance Progress",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Ink
                                    )

                                    Text(
                                        "Overall completion",
                                        fontSize = 12.sp,
                                        color = Muted
                                    )
                                }

                                Text(
                                    "25%",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Brand
                                )
                            }

                            Spacer(Modifier.height(8.dp))

                            LinearProgressIndicator(
                                progress = { 0.25f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(CircleShape),
                                color = Brand,
                                trackColor = Border
                            )

                            Spacer(Modifier.height(5.dp))

                            Text(
                                "1 of 4 steps completed",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Muted
                            )
                        }
                    }

                    // STATUS CARDS
                    Column(
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            "Clearance Overview",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Ink
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            StatusTile(
                                Modifier.weight(1f),
                                "Approved",
                                "1",
                                Icons.Default.CheckCircle,
                                Green,
                                SoftGreen
                            )

                            StatusTile(
                                Modifier.weight(1f),
                                "Pending",
                                "2",
                                Icons.Default.Schedule,
                                Orange,
                                SoftOrange
                            )

                            StatusTile(
                                Modifier.weight(1f),
                                "Returned",
                                "0",
                                Icons.Default.Refresh,
                                Red,
                                SoftRed
                            )
                        }
                    }

                    // QUICK ACTIONS
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.GridView,
                                contentDescription = null,
                                tint = Brand,
                                modifier = Modifier.size(23.dp)
                            )

                            Spacer(Modifier.width(7.dp))

                            Text(
                                "Quick Actions",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Ink,
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                "8 services",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Brand
                            )
                        }

                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            actions.chunked(4).forEach { rowActions ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowActions.forEach { action ->
                                        CompactAction(
                                            modifier = Modifier.weight(1f),
                                            action = action,
                                            compact = compact,
                                            onClick = {
                                                when (action.title) {
                                                    "My Clearance" -> onClearance()
                                                    "Submit" -> onRequirements()
                                                    "Logout" -> onLogout()

                                                    else -> {
                                                        Toast.makeText(
                                                            context,
                                                            "${action.title} page is coming soon.",
                                                            Toast.LENGTH_SHORT
                                                        ).show()
                                                    }
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // DEADLINE REMINDER
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(15.dp))
                            .background(SoftMaroon)
                            .border(
                                1.dp,
                                Color(0xFFEBD0D9),
                                RoundedCornerShape(15.dp)
                            )
                            .padding(
                                horizontal = 11.dp,
                                vertical = if (tiny) 8.dp else 10.dp
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconTile(
                            Icons.Default.CalendarMonth,
                            Color.White,
                            Brand,
                            40.dp
                        )

                        Spacer(Modifier.width(10.dp))

                        Column(Modifier.weight(1f)) {
                            Text(
                                "Deadline Reminder",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepBrand
                            )

                            Text(
                                "Complete all requirements on time.",
                                fontSize = 11.sp,
                                color = Ink,
                                maxLines = 2,
                                lineHeight = 14.sp
                            )
                        }

                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = Brand,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IconTile(
    icon: ImageVector,
    tint: Color,
    background: Color,
    size: androidx.compose.ui.unit.Dp
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(11.dp))
            .background(background),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(size * 0.6f)
        )
    }
}

@Composable
private fun StatusTile(
    modifier: Modifier,
    title: String,
    count: String,
    icon: ImageVector,
    tint: Color,
    background: Color
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(13.dp))
            .background(background)
            .border(
                1.dp,
                tint.copy(alpha = 0.2f),
                RoundedCornerShape(13.dp)
            )
            .padding(horizontal = 6.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )

        Spacer(Modifier.width(5.dp))

        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                count,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Ink,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun CompactAction(
    modifier: Modifier = Modifier,
    action: ActionItem,
    compact: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .height(if (compact) 82.dp else 90.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(Color.White)
            .border(1.dp, Border, RoundedCornerShape(13.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 3.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 39.dp else 44.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(action.background),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = action.icon,
                contentDescription = action.title,
                tint = action.tint,
                modifier = Modifier.size(if (compact) 25.dp else 29.dp)
            )
        }

        Spacer(Modifier.height(5.dp))

        Text(
            text = action.title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Ink,
            maxLines = 2,
            lineHeight = 12.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}
