
package com.example.digitalclearancesystem

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val LoginMaroon = Color(0xFF801824)
private val LoginDarkMaroon = Color(0xFF65121D)
private val LoginSoftPink = Color(0xFFFCF7F7)
private val LoginGray = Color(0xFF6F686A)

private const val LOGIN_API_URL =
    "http://10.0.2.2/citcs_api/login.php"

@Composable
fun LoginScreen(
    onLoginSuccess: (String) -> Unit,
    onRegister: () -> Unit,
    onRecover: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var studentNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LoginSoftPink)
    ) {
        // Bottom decorative campus illustration
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp)
                .align(Alignment.BottomCenter)
        ) {
            val c = LoginDarkMaroon.copy(alpha = 0.075f)
            val w = size.width
            val h = size.height

            drawOval(
                c,
                Offset(w * .08f, h * .76f),
                Size(w * .84f, h * .18f)
            )
            drawRect(
                c,
                Offset(w * .27f, h * .38f),
                Size(w * .46f, h * .43f)
            )
            drawRect(
                c,
                Offset(w * .39f, h * .20f),
                Size(w * .22f, h * .61f)
            )

            val roof = Path().apply {
                moveTo(w * .34f, h * .38f)
                lineTo(w * .50f, h * .10f)
                lineTo(w * .66f, h * .38f)
                close()
            }
            drawPath(roof, c)

            drawRect(
                c,
                Offset(w * .10f, h * .52f),
                Size(w * .17f, h * .29f)
            )
            drawRect(
                c,
                Offset(w * .73f, h * .52f),
                Size(w * .17f, h * .29f)
            )

            for (i in 0..2) {
                val x = w * (.31f + i * .13f)

                drawRect(
                    LoginSoftPink.copy(alpha = .75f),
                    Offset(x, h * .48f),
                    Size(w * .055f, h * .09f)
                )
                drawRect(
                    LoginSoftPink.copy(alpha = .75f),
                    Offset(x, h * .64f),
                    Size(w * .055f, h * .09f)
                )
            }

            drawRect(
                LoginSoftPink.copy(alpha = .8f),
                Offset(w * .46f, h * .62f),
                Size(w * .08f, h * .19f)
            )
            drawLine(
                c,
                Offset(w * .5f, h * .1f),
                Offset(w * .5f, h * .01f),
                2.dp.toPx()
            )
        }

        // Top wave
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp)
                .align(Alignment.TopCenter)
        ) {
            val wave = Path().apply {
                moveTo(0f, 0f)
                lineTo(size.width, 0f)
                lineTo(size.width, size.height * .65f)

                cubicTo(
                    size.width * .76f,
                    size.height * .91f,
                    size.width * .63f,
                    size.height * .53f,
                    size.width * .45f,
                    size.height * .62f
                )

                cubicTo(
                    size.width * .25f,
                    size.height * .70f,
                    size.width * .15f,
                    size.height * .99f,
                    0f,
                    size.height * .77f
                )
                close()
            }
            drawPath(wave, LoginMaroon)
        }

        // Bottom wave
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(78.dp)
                .align(Alignment.BottomCenter)
        ) {
            val wave = Path().apply {
                moveTo(0f, size.height * .36f)

                cubicTo(
                    size.width * .20f,
                    size.height * .05f,
                    size.width * .34f,
                    size.height * .72f,
                    size.width * .55f,
                    size.height * .46f
                )

                cubicTo(
                    size.width * .76f,
                    size.height * .17f,
                    size.width * .88f,
                    size.height * .16f,
                    size.width,
                    size.height * .36f
                )

                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(wave, LoginMaroon)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(65.dp))

            Image(
                painter = painterResource(id = R.drawable.citcs_logo),
                contentDescription = "CITCS school logo",
                modifier = Modifier.size(58.dp)
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = "CITCS",
                fontSize = 27.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
                color = LoginDarkMaroon
            )

            Spacer(Modifier.height(2.dp))

            Text(
                text = "DIGITAL CLEARANCE SYSTEM",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = .8.sp,
                color = LoginMaroon,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(7.dp))

            Text(
                text = "Your clearance, made easier.",
                fontSize = 12.sp,
                color = LoginGray
            )

            Spacer(Modifier.height(20.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        12.dp,
                        RoundedCornerShape(22.dp),
                        spotColor = LoginDarkMaroon.copy(alpha = .15f)
                    )
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White)
                    .padding(horizontal = 18.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Welcome Back!",
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    color = LoginDarkMaroon,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(5.dp))

                Text(
                    text = "Sign in to access your account.",
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 13.sp,
                    color = LoginGray,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(22.dp))

                Text(
                    text = "Student Number / Email",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoginDarkMaroon
                )

                Spacer(Modifier.height(7.dp))

                OutlinedTextField(
                    value = studentNumber,
                    onValueChange = { studentNumber = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text(
                            "Enter student number or email",
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = null,
                            tint = LoginMaroon
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LoginMaroon,
                        unfocusedBorderColor = Color(0xFFD8CECE),
                        cursorColor = LoginMaroon
                    )
                )

                Spacer(Modifier.height(15.dp))

                Text(
                    text = "Password",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoginDarkMaroon
                )

                Spacer(Modifier.height(7.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text("Enter your password", fontSize = 13.sp)
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = LoginMaroon
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                passwordVisible = !passwordVisible
                            }
                        ) {
                            Icon(
                                imageVector = if (passwordVisible) {
                                    Icons.Default.VisibilityOff
                                } else {
                                    Icons.Default.Visibility
                                },
                                contentDescription = "Toggle password visibility"
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LoginMaroon,
                        unfocusedBorderColor = Color(0xFFD8CECE),
                        cursorColor = LoginMaroon
                    )
                )

                Spacer(Modifier.height(7.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = rememberMe,
                        onCheckedChange = { rememberMe = it },
                        enabled = !isLoading,
                        colors = CheckboxDefaults.colors(
                            checkedColor = LoginMaroon
                        )
                    )

                    Text(
                        text = "Remember Me",
                        fontSize = 11.sp,
                        color = LoginGray
                    )

                    Spacer(Modifier.weight(1f))

                    TextButton(
                        onClick = onRecover,
                        enabled = !isLoading,
                        contentPadding = PaddingValues(
                            horizontal = 2.dp,
                            vertical = 4.dp
                        )
                    ) {
                        Text(
                            text = "Forgot Password?",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LoginDarkMaroon
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                Button(
                    onClick = {
                        val identifier = studentNumber.trim()
                        val enteredPassword = password

                        if (
                            identifier.isBlank() ||
                            enteredPassword.isBlank()
                        ) {
                            Toast.makeText(
                                context,
                                "Enter your student number/email and password.",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            scope.launch {
                                isLoading = true

                                try {
                                    val result = performLogin(
                                        identifier = identifier,
                                        password = enteredPassword
                                    )

                                    if (result.success) {
                                        Toast.makeText(
                                            context,
                                            result.message,
                                            Toast.LENGTH_SHORT
                                        ).show()

                                        onLoginSuccess(result.studentName)
                                    } else {
                                        Toast.makeText(
                                            context,
                                            result.message,
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        context,
                                        "Cannot connect to the API. Check XAMPP, network settings, and login.php.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } finally {
                                    isLoading = false
                                }
                            }
                        }
                    },
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LoginMaroon
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = "LOGIN",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(Modifier.width(10.dp))

                        Icon(
                            Icons.Default.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HorizontalDivider(
                        Modifier.weight(1f),
                        color = Color(0xFFE6DEDE)
                    )

                    Text(
                        "  OR  ",
                        fontSize = 11.sp,
                        color = LoginGray
                    )

                    HorizontalDivider(
                        Modifier.weight(1f),
                        color = Color(0xFFE6DEDE)
                    )
                }

                Spacer(Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onRegister,
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, LoginMaroon),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = LoginDarkMaroon
                    )
                ) {
                    Icon(
                        Icons.Default.PersonAdd,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )

                    Spacer(Modifier.width(8.dp))

                    Text(
                        text = "Create an Account",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = "COLLEGE OF INFORMATION TECHNOLOGY",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = .65.sp,
                color = LoginDarkMaroon,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(3.dp))

            Text(
                text = "AND COMPUTER STUDIES",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = LoginDarkMaroon,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(90.dp))
        }
    }
}

private data class LoginResult(
    val success: Boolean,
    val message: String,
    val studentName: String = ""
)

private suspend fun performLogin(
    identifier: String,
    password: String
): LoginResult = withContext(Dispatchers.IO) {

    val connection = URL(LOGIN_API_URL)
        .openConnection() as HttpURLConnection

    try {
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 15000
        connection.doOutput = true

        connection.setRequestProperty(
            "Content-Type",
            "application/json; charset=UTF-8"
        )
        connection.setRequestProperty(
            "Accept",
            "application/json"
        )

        val requestJson = JSONObject().apply {
            put("student_number", identifier)
            put("password", password)
        }

        connection.outputStream.use { output ->
            output.write(
                requestJson.toString().toByteArray(Charsets.UTF_8)
            )
        }

        val statusCode = connection.responseCode

        val responseStream = if (statusCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }

        val responseText = responseStream
            ?.bufferedReader()
            ?.use { it.readText() }
            .orEmpty()

        val responseJson = try {
            JSONObject(responseText)
        } catch (_: Exception) {
            JSONObject()
        }

        val success = responseJson.optBoolean("success", false)

        val message = responseJson.optString(
            "message",
            when (statusCode) {
                401 -> "Incorrect student number/email or password."
                404 -> "Login API endpoint not found."
                500 -> "Server error. Check the PHP and database configuration."
                else -> "Login failed. Please try again."
            }
        )

        if (!success) {
            return@withContext LoginResult(
                success = false,
                message = message
            )
        }

        val student = responseJson.optJSONObject("student")
            ?: return@withContext LoginResult(
                success = false,
                message = "Student information is missing from the server response."
            )

        val firstName = student.optString("first_name").trim()
        val lastName = student.optString("last_name").trim()

        val fullName = listOf(firstName, lastName)
            .filter { it.isNotBlank() }
            .joinToString(" ")

        if (fullName.isBlank()) {
            return@withContext LoginResult(
                success = false,
                message = "Student name is missing from the server response."
            )
        }

        LoginResult(
            success = true,
            message = message,
            studentName = fullName
        )
    } finally {
        connection.disconnect()
    }
}
