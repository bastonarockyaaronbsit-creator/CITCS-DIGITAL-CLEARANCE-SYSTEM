package com.example.digitalclearancesystem

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ReqBackground = Color(0xFFF5F7FB)
private val ReqPrimary = Color(0xFF173B67)
private val ReqBlue = Color(0xFF2878C7)
private val ReqGreen = Color(0xFF21865B)
private val ReqRed = Color(0xFFD64B4B)
private val ReqOrange = Color(0xFFE59A27)
private val ReqText = Color(0xFF202B3C)
private val ReqMuted = Color(0xFF788397)

data class RequirementItem(
    val id: Int,
    val title: String,
    val description: String,
    val status: String
)

@Composable
fun RequirementsScreen(
    onHome: () -> Unit = {},
    onClearance: () -> Unit = {},
    onRequirements: () -> Unit = {},
    onNotifications: () -> Unit = {},
    onProfile: () -> Unit = {},
    onSubmitRequirement: () -> Unit = {},
    onRequirementClick: (Int) -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf("All") }

    val requirements = listOf(
        RequirementItem(1, "Certificate of Registration", "Submit a copy of your current registration form.", "Submitted"),
        RequirementItem(2, "School ID", "Provide a clear copy of your valid school identification card.", "Missing"),
        RequirementItem(3, "Latest Assessment Form", "Submit your latest assessment or billing statement.", "Submitted"),
        RequirementItem(4, "Library Clearance", "Make sure all library obligations are settled.", "Missing"),
        RequirementItem(5, "Laboratory Clearance", "Submit your laboratory clearance if applicable.", "Submitted"),
        RequirementItem(6, "Payment Receipt", "Provide proof of payment when required.", "Missing"),
        RequirementItem(7, "Student Information Sheet", "Submit your updated student information sheet.", "Submitted"),
        RequirementItem(8, "Other Supporting Documents", "Upload other documents requested by the office.", "Missing")
    )

    val filteredRequirements = when (selectedTab) {
        "Missing" -> requirements.filter { it.status == "Missing" }
        else -> requirements
    }

    Scaffold(
        containerColor = ReqBackground,
        bottomBar = {
            RequirementsBottomBar(
                onHome = onHome,
                onClearance = onClearance,
                onRequirements = onRequirements,
                onNotifications = onNotifications,
                onProfile = onProfile
            )
        }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ReqBackground)
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
        ) {

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "Student Portal",
                fontSize = 14.sp,
                color = ReqMuted,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Requirements",
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold,
                color = ReqText
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "View and monitor the documents needed for your clearance.",
                fontSize = 13.sp,
                color = ReqMuted,
                lineHeight = 19.sp
            )

            Spacer(modifier = Modifier.height(22.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RequirementSummaryCard(
                    title = "Total",
                    count = requirements.size.toString(),
                    color = ReqPrimary,
                    modifier = Modifier.weight(1f)
                )

                RequirementSummaryCard(
                    title = "Submitted",
                    count = requirements.count { it.status == "Submitted" }.toString(),
                    color = ReqGreen,
                    modifier = Modifier.weight(1f)
                )

                RequirementSummaryCard(
                    title = "Missing",
                    count = requirements.count { it.status == "Missing" }.toString(),
                    color = ReqRed,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(25.dp))

            Text(
                text = "Required Documents",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = ReqText
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE8EDF4), RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("All", "Missing").forEach { tab ->
                    val isSelected = selectedTab == tab

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isSelected) Color.White else Color.Transparent,
                                RoundedCornerShape(9.dp)
                            )
                            .clickable { selectedTab = tab }
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) ReqPrimary else ReqMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(11.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(filteredRequirements, key = { it.id }) { item ->
                    RequirementCard(
                        item = item,
                        onClick = { onRequirementClick(item.id) }
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .background(Color(0xFFEAF2FC), RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Reminder: ",
                    color = ReqPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Submit all missing documents to complete your requirements.",
                    color = ReqText,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun RequirementSummaryCard(
    title: String,
    count: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 15.dp, horizontal = 12.dp)
        ) {
            Text(
                text = count,
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = title,
                fontSize = 11.sp,
                color = ReqMuted,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun RequirementCard(
    item: RequirementItem,
    onClick: () -> Unit
) {
    val statusColor = if (item.status == "Submitted") ReqGreen else ReqRed
    val statusBackground = if (item.status == "Submitted") {
        Color(0xFFE6F5ED)
    } else {
        Color(0xFFFCEAEA)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(43.dp)
                    .background(Color(0xFFEAF1FA), RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Article,
                    contentDescription = null,
                    tint = ReqPrimary
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = item.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ReqText
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = item.description,
                    fontSize = 11.sp,
                    color = ReqMuted,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = statusBackground,
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = item.status,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = "›",
                fontSize = 25.sp,
                color = ReqMuted
            )
        }
    }
}

@Composable
private fun RequirementsBottomBar(
    onHome: () -> Unit,
    onClearance: () -> Unit,
    onRequirements: () -> Unit,
    onNotifications: () -> Unit,
    onProfile: () -> Unit
) {
    Surface(
        color = Color.White,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 9.dp, horizontal = 5.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(Icons.Default.Home, "Home", false, onHome)
            BottomNavItem(Icons.Default.Article, "Clearance", false, onClearance)
            BottomNavItem(Icons.Default.Folder, "Requirements", true, onRequirements)
            BottomNavItem(Icons.Default.Notifications, "Notifications", false, onNotifications)
            BottomNavItem(Icons.Default.Person, "Profile", false, onProfile)
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 7.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) ReqPrimary else ReqMuted,
            modifier = Modifier.size(21.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) ReqPrimary else ReqMuted
        )
    }
}