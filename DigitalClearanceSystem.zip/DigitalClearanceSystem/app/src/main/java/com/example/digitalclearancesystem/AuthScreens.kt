
package com.example.digitalclearancesystem

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val CitcsMaroon = Color(0xFF800020)
private val CitcsPink = Color(0xFFF7E8EE)
private val CitcsText = Color(0xFF292329)
private val CitcsHint = Color(0xFF777078)

private const val API_BASE_URL = "http://10.0.2.2/citcs_api/"

@Composable
fun RegisterScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var fullName by remember { mutableStateOf("") }
    var studentNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack) {
                    Text(
                        text = "← Back",
                        color = CitcsMaroon
                    )
                }

                Text(
                    text = "CREATE ACCOUNT",
                    modifier = Modifier.weight(1f),
                    color = CitcsMaroon,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.weight(0.35f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "CITCS",
                color = CitcsMaroon,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Text(
                text = "Digital Clearance System",
                color = CitcsHint,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Create your student account",
                modifier = Modifier.fillMaxWidth(),
                color = CitcsText,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(10.dp))

            AuthFieldLabel("Full Name")

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Enter your first and last name") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                ),
                colors = authFieldColors()
            )

            Spacer(modifier = Modifier.height(8.dp))

            AuthFieldLabel("Student Number")

            OutlinedTextField(
                value = studentNumber,
                onValueChange = { studentNumber = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Enter your student number") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                ),
                colors = authFieldColors()
            )

            Spacer(modifier = Modifier.height(8.dp))

            AuthFieldLabel("Password")

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("At least 8 characters") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                colors = authFieldColors()
            )

            Spacer(modifier = Modifier.height(8.dp))

            AuthFieldLabel("Confirm Password")

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Re-enter your password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),
                colors = authFieldColors()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val cleanName = fullName.trim()
                    val cleanStudentNumber = studentNumber.trim()

                    when {
                        cleanName.isBlank() ||
                                cleanStudentNumber.isBlank() ||
                                password.isBlank() ||
                                confirmPassword.isBlank() -> {
                            Toast.makeText(
                                context,
                                "Please complete all fields",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        cleanName.split(Regex("\\s+")).size < 2 -> {
                            Toast.makeText(
                                context,
                                "Please enter your first and last name",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        password.length < 8 -> {
                            Toast.makeText(
                                context,
                                "Password must be at least 8 characters",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        password != confirmPassword -> {
                            Toast.makeText(
                                context,
                                "Passwords do not match",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        else -> {
                            scope.launch {
                                isLoading = true

                                try {
                                    val result = sendRegistrationRequest(
                                        fullName = cleanName,
                                        studentNumber = cleanStudentNumber,
                                        password = password
                                    )

                                    Toast.makeText(
                                        context,
                                        result.second,
                                        Toast.LENGTH_LONG
                                    ).show()

                                    if (result.first) {
                                        onBack()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        context,
                                        "Cannot connect to server. Check XAMPP and try again.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } finally {
                                    isLoading = false
                                }
                            }
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CitcsMaroon
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "CREATE ACCOUNT",
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            TextButton(onClick = onBack) {
                Text(
                    text = "Already have an account? Log in",
                    color = CitcsMaroon,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun RecoverScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current

    var studentNumber by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextButton(
                onClick = onBack,
                modifier = Modifier.align(Alignment.Start)
            ) {
                Text("← Back", color = CitcsMaroon)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "RECOVER PASSWORD",
                color = CitcsMaroon,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Enter your student number to request password recovery.",
                color = CitcsHint,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            AuthFieldLabel("Student Number")

            OutlinedTextField(
                value = studentNumber,
                onValueChange = { studentNumber = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Enter your student number") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = authFieldColors()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (studentNumber.isBlank()) {
                        Toast.makeText(
                            context,
                            "Please enter your student number",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            context,
                            "Password recovery is not connected yet.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CitcsMaroon
                )
            ) {
                Text("SUBMIT REQUEST")
            }
        }
    }
}

@Composable
fun AuthFieldLabel(
    text: String
) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 5.dp),
        color = CitcsText,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold
    )
}

@Composable
fun authFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = CitcsMaroon,
    unfocusedBorderColor = Color(0xFFD8CBD0),
    focusedLabelColor = CitcsMaroon,
    cursorColor = CitcsMaroon,
    focusedTextColor = CitcsText,
    unfocusedTextColor = CitcsText,
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White
)

private suspend fun sendRegistrationRequest(
    fullName: String,
    studentNumber: String,
    password: String
): Pair<Boolean, String> = withContext(Dispatchers.IO) {
    val connection = URL(
        "${API_BASE_URL}register.php"
    ).openConnection() as HttpURLConnection

    try {
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 15000
        connection.doOutput = true

        connection.setRequestProperty(
            "Content-Type",
            "application/json; charset=UTF-8"
        )
        connection.setRequestProperty(
            "Accept",
            "application/json"
        )

        val requestJson = JSONObject().apply {
            put("full_name", fullName)
            put("student_number", studentNumber)
            put("password", password)
        }

        connection.outputStream.use { output ->
            output.write(
                requestJson.toString().toByteArray(Charsets.UTF_8)
            )
        }

        val statusCode = connection.responseCode

        val responseStream = if (statusCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }

        val responseText = responseStream
            ?.bufferedReader()
            ?.use { it.readText() }
            .orEmpty()

        val responseJson = try {
            JSONObject(responseText)
        } catch (_: Exception) {
            JSONObject()
        }

        val success = responseJson.optBoolean("success", false)

        val message = responseJson.optString(
            "message",
            if (success) {
                "Account created successfully!"
            } else {
                "Registration failed. Please try again."
            }
        )

        Pair(success, message)
    } finally {
        connection.disconnect()
    }
}
