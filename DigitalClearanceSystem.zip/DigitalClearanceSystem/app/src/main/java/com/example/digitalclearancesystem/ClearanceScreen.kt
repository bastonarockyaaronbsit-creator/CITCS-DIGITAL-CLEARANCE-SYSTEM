
package com.example.digitalclearancesystem

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image

private val ClearanceMaroon = Color(0xFF801824)
private val ClearanceDark = Color(0xFF650F1B)
private val ClearancePink = Color(0xFFFCF3F5)
private val ClearanceBorder = Color(0xFFF0D9DF)
private val ClearanceGray = Color(0xFF64748B)

private val ApprovedGreen = Color(0xFF079653)
private val ApprovedBg = Color(0xFFD7F5E5)

private val PendingOrange = Color(0xFFED8A00)
private val PendingBg = Color(0xFFFFEDCB)

private val RejectedRed = Color(0xFFE51D3D)
private val RejectedBg = Color(0xFFFFD9E0)

private data class OfficeStatus(
    val name: String,
    val description: String,
    val requirement: String,
    val status: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun ClearanceScreen(
    onBack: () -> Unit = {},
    onViewRequirements: () -> Unit = {},
    onHome: () -> Unit = {},
    onRequirements: () -> Unit = {},
    onNotifications: () -> Unit = {},
    onProfile: () -> Unit = {}
) {

    val offices = listOf(
        OfficeStatus(
            name = "Registrar",
            description = "All requirements complete.",
            requirement = "",
            status = "Approved",
            icon = Icons.Default.Description
        ),
        OfficeStatus(
            name = "Library",
            description = "All requirements complete.",
            requirement = "",
            status = "Approved",
            icon = Icons.Default.MenuBook
        ),
        OfficeStatus(
            name = "Finance",
            description = "1 pending requirement",
            requirement = "Payment verification",
            status = "Pending",
            icon = Icons.Default.AccountBalanceWallet
        ),
        OfficeStatus(
            name = "Department",
            description = "Incomplete document",
            requirement = "Official receipt",
            status = "Rejected",
            icon = Icons.Default.Groups
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {

        // HEADER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp)
                .background(ClearanceDark)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .padding(horizontal = 22.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(
                            id = R.drawable.citcs_logo
                        ),
                        contentDescription = "CITCS Logo",
                        modifier = Modifier.size(55.dp)
                    )

                    Spacer(Modifier.width(14.dp))

                    Text(
                        text = "Digital Clearance System",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Curved-style bottom accent
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(18.dp)
                    .align(Alignment.BottomCenter)
                    .clip(
                        RoundedCornerShape(
                            topStart = 50.dp,
                            topEnd = 50.dp
                        )
                    )
                    .background(Color(0xFFE9AAB6))
            )
        }

        // MAIN CONTENT
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFFFFFAFB))
                .padding(horizontal = 22.dp)
        ) {

            Spacer(Modifier.height(12.dp))

            // TITLE
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = ClearanceMaroon
                    )
                }

                Text(
                    text = "Clearance Status",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    color = ClearanceDark
                )
            }

            Text(
                text = "Track the status of your clearance requirements\nand see your overall progress.",
                fontSize = 12.sp,
                color = ClearanceGray,
                modifier = Modifier.padding(start = 30.dp)
            )

            Spacer(Modifier.height(15.dp))

            // OVERALL PROGRESS CARD
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(13.dp))
                    .background(ClearancePink)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier.size(86.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { 0.75f },
                        modifier = Modifier.fillMaxSize(),
                        color = ClearanceMaroon,
                        trackColor = Color(0xFFE8C8D0),
                        strokeWidth = 9.dp
                    )

                    Text(
                        text = "75%",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        color = ClearanceDark
                    )
                }

                Spacer(Modifier.width(20.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Overall Progress",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = ClearanceDark
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "3 of 4 offices completed",
                        fontSize = 12.sp,
                        color = ClearanceGray
                    )

                    Spacer(Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { 0.75f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(9.dp)
                            .clip(CircleShape),
                        color = ClearanceMaroon,
                        trackColor = Color(0xFFE0DDE0)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Text(
                text = "Office Clearance Status",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = ClearanceDark
            )

            Spacer(Modifier.height(8.dp))

            // OFFICE STATUS CARDS
            offices.forEach { office ->
                OfficeStatusCard(office)
                Spacer(Modifier.height(9.dp))
            }

            // SUMMARY
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(ClearancePink)
                    .padding(11.dp)
            ) {
                Text(
                    text = "Summary",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ClearanceDark
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SummaryItem(
                        count = "2",
                        label = "Approved",
                        color = ApprovedGreen,
                        modifier = Modifier.weight(1f)
                    )

                    SummaryItem(
                        count = "1",
                        label = "Pending",
                        color = PendingOrange,
                        modifier = Modifier.weight(1f)
                    )

                    SummaryItem(
                        count = "1",
                        label = "Rejected",
                        color = RejectedRed,
                        modifier = Modifier.weight(1f)
                    )

                    SummaryItem(
                        count = "4",
                        label = "Total Offices",
                        color = ClearanceDark,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(11.dp))

            // VIEW REQUIREMENTS BUTTON
            Button(
                onClick = onViewRequirements,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(30.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ClearanceDark
                )
            ) {
                Icon(
                    Icons.Default.Description,
                    contentDescription = null
                )

                Spacer(Modifier.width(10.dp))

                Text(
                    text = "View Requirements",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(Modifier.weight(1f))

                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null
                )
            }

            Spacer(Modifier.height(8.dp))
        }

        // BOTTOM NAVIGATION
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(76.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 22.dp,
                        topEnd = 22.dp
                    )
                )
                .background(ClearanceDark),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {

            BottomNavItem(
                icon = Icons.Default.Home,
                label = "Home",
                selected = false,
                onClick = onHome
            )

            BottomNavItem(
                icon = Icons.Default.Assignment,
                label = "Clearance",
                selected = true,
                onClick = {}
            )

            BottomNavItem(
                icon = Icons.Default.FolderOpen,
                label = "Requirements",
                selected = false,
                onClick = onRequirements
            )

            BottomNavItem(
                icon = Icons.Default.Notifications,
                label = "Notifications",
                selected = false,
                onClick = onNotifications
            )

            BottomNavItem(
                icon = Icons.Default.Person,
                label = "Profile",
                selected = false,
                onClick = onProfile
            )
        }
    }
}

@Composable
private fun OfficeStatusCard(
    office: OfficeStatus
) {
    val statusColor = when (office.status) {
        "Approved" -> ApprovedGreen
        "Pending" -> PendingOrange
        else -> RejectedRed
    }

    val statusBackground = when (office.status) {
        "Approved" -> ApprovedBg
        "Pending" -> PendingBg
        else -> RejectedBg
    }

    val statusIcon = when (office.status) {
        "Approved" -> Icons.Default.CheckCircle
        "Pending" -> Icons.Default.AccessTime
        else -> Icons.Default.Cancel
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ClearancePink)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(ClearanceMaroon),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = office.icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(25.dp)
            )
        }

        Spacer(Modifier.width(13.dp))

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = office.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ClearanceDark
            )

            Text(
                text = office.description,
                fontSize = 11.sp,
                color = ClearanceGray
            )

            if (office.requirement.isNotBlank()) {
                Spacer(Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Description,
                        contentDescription = null,
                        tint = ClearanceGray,
                        modifier = Modifier.size(14.dp)
                    )

                    Spacer(Modifier.width(5.dp))

                    Text(
                        text = office.requirement,
                        fontSize = 10.sp,
                        color = ClearanceGray
                    )
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.End
        ) {
            Row(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(statusBackground)
                    .padding(horizontal = 9.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = statusIcon,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(16.dp)
                )

                Spacer(Modifier.width(5.dp))

                Text(
                    text = office.status,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor
                )
            }
        }

        Spacer(Modifier.width(5.dp))

        Icon(
            Icons.Default.ChevronRight,
            contentDescription = "View office",
            tint = ClearanceMaroon,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun SummaryItem(
    count: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = count,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )

        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = color,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun BottomNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) {
                Color.White
            } else {
                Color(0xFFD9AEB6)
            },
            modifier = Modifier.size(23.dp)
        )

        Spacer(Modifier.height(3.dp))

        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = if (selected) {
                FontWeight.Bold
            } else {
                FontWeight.Normal
            },
            color = if (selected) {
                Color.White
            } else {
                Color(0xFFD9AEB6)
            }
        )

        if (selected) {
            Spacer(Modifier.height(2.dp))
            Box(
                modifier = Modifier
                    .width(35.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(Color.White)
            )
        }
    }
}
